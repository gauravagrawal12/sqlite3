//
//  wrapper.swift
//  SQLite ToDoList
//
//  Created by Felix 05 on 17/12/19.
//  Copyright © 2019 felix. All rights reserved.
//

import Foundation
import SQLite3
class DBwrapper
{
    static let shareObj = DBwrapper()
    var taskNameArray : [String]!
    var taskIdArray : [String]!
    func getDatabasepath() -> String {
        let Dir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let dbpath = Dir.first!
        return dbpath + "MyDatabase.sqlite"
    }
    func executeQuery(Query:String) -> Bool
    {
        var db:OpaquePointer? = nil
        var stmt:OpaquePointer? = nil
        var success = false
        let database = getDatabasepath()
        if sqlite3_open(database, &db) == SQLITE_OK
        {
            if sqlite3_prepare_v2(db!, Query, -1, &stmt, nil) == SQLITE_OK
            {
                if (sqlite3_step(stmt!) == SQLITE_DONE)
                {
                    success = true
                    sqlite3_finalize(stmt!)
                    sqlite3_close(db!)
                }
                else
                {
                    print("error in step-execution \(sqlite3_errmsg(db!))")
                }
            }
            else
            {
                print("error in prapare v2 \(sqlite3_errmsg(db!))")
                    
                }
        }
            else
            {
                print("error in oprn \(sqlite3_errmsg(db!))")
            }
            return success
        }
        func getAllTask(Query:String)
        {
            taskIdArray = [String]()
            
            taskNameArray = [String]()
            var db:OpaquePointer? = nil
            var stmt:OpaquePointer? = nil
            
            let databasepath = getDatabasepath()
            if sqlite3_open(databasepath, &db) == SQLITE_OK
            {
                if sqlite3_prepare_v2(db!, Query, -1, &stmt, nil) == SQLITE_OK
                {
                    while sqlite3_step(stmt!) == SQLITE_ROW
                    {
                        let tid = sqlite3_column_text(stmt, 0)
                        let taskid = String(cString: tid!)
                        taskIdArray.append(taskid)
                        let tnmae = sqlite3_column_text(stmt, 1)
                        let taskname = String(cString: tnmae!)
                        taskNameArray.append(taskname)
                    }
                    print("ids = \(taskIdArray)")
                    print("names = \(taskNameArray)")
                }
            
            else
            {
                print("error in prepare v2 \(sqlite3_errmsg(db!))")
            }
    }
        
            else
            {
                print("error in open \(sqlite3_errmsg(db!))")
            }
}
func createTable()
{
    let createQuery = "create table if not exists taskTable(textId text , textName text)"
    let isSuccess = executeQuery(Query: createQuery)
        if isSuccess
    {
        print("table creation : success")
    }
    else
        {
            print("table creation : Failed")
    }
}
}
