//
//  ViewController.swift
//  SQLite ToDoList
//
//  Created by Felix 05 on 17/12/19.
//  Copyright © 2019 felix. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource , UITableViewDelegate
{
    var tidArray = [String]()
    var tnameArray = [String]()
    
    override func viewWillAppear(_ animated: Bool) {
        let seletQuery = "Select * from tasktable"
        DBwrapper.shareObj.getAllTask(Query: seletQuery)
        tidArray = DBwrapper.shareObj.taskIdArray
        tnameArray = DBwrapper.shareObj.taskNameArray
        TableView.reloadData()
        print(tidArray)
        print(tnameArray)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath)
        let id = cell?.textLabel?.text
        let name = cell?.detailTextLabel?.text
        let edit = storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
        edit.taskid = id!
        edit.taskname = name!
        navigationController?.pushViewController(edit, animated: true)
        
    
    
        
    }
    
    
    @IBOutlet weak var TableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TableView.delegate = self
        TableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tidArray.count
    }
    
     public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
     {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.textLabel?.text = tidArray[indexPath.row]
        cell.detailTextLabel?.text = tnameArray[indexPath.row]
        return cell
        
        
    }
    
    
    @IBAction func Nextbutton(_ sender: UIBarButtonItem) {
        let next = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        navigationController?.pushViewController(next, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

