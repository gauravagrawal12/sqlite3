//
//  EditViewController.swift
//  SQLite ToDoList
//
//  Created by Felix 05 on 17/12/19.
//  Copyright © 2019 felix. All rights reserved.
//

import UIKit

class EditViewController: UIViewController {
    
    var taskid = String()
    var taskname = String()
    
    @IBOutlet weak var textId: UITextField!
    
    
    @IBOutlet weak var textName: UITextField!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        textId.text = taskid
        textName.text = taskname
        

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func update(_ sender: UIButton) {
        
        let update = "update taskTable set textid = '\(textId.text!)' where textName =      '\(textName.text!)'"
        let isSuccess = DBwrapper.shareObj.executeQuery(Query: update)
        if isSuccess
        {
            print("update successful")
        }
        else
        {
            print("update failed")
        }
        
    }
    
    
    @IBAction func Delete(_ sender: UIButton) {
        
        let deleteQuery = "delete from taskTable where textid = '\(textId.text!)'"
        let isSuccess = DBwrapper.shareObj.executeQuery(Query: deleteQuery)
        if isSuccess
        {
            print("delete : success")
        }
        else
        {
            print("delete : failed")
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
